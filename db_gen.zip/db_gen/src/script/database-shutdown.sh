cd ../../config/
docker-compose down -v
docker-compose stop
docker-compose rm -f