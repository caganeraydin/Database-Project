CREATE SCHEMA "project_schema";
GRANT USAGE ON SCHEMA "project_schema" TO "project_csi2132" ;
