CREATE USER test WITH PASSWORD 'test';
GRANT ALL PRIVILEGES ON DATABASE "test_db" TO test;

COMMENT ON DATABASE "test_db" IS 'Database for the test';
